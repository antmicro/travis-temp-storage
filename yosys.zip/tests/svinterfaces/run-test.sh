#/bin/bash -e



./runone.sh  svinterface1
./runone.sh  svinterface_at_top
